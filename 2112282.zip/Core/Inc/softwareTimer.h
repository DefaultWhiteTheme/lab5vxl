/*
 * softwareTimer.h
 *
 *  Created on: Dec 12, 2023
 *      Author: QUI
 */

#ifndef INC_SOFTWARETIMER_H_
#define INC_SOFTWARETIMER_H_

extern int counter1;
extern int flag1;

void setTimer(int duration);
void runTimer();

#endif /* INC_SOFTWARETIMER_H_ */
